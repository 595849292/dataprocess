f_space_sta <-
function(x){
  return(sum(x==" ",na.rm = TRUE))
}
