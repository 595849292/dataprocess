f_empty_sta <-
function(x){
  return(sum(x=="",na.rm = TRUE))
}
