f_na_sta <-
function(x){
  return(sum(is.na(x)))
}
