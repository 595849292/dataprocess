f_outlier_deep <-
function(x,x1,x2){
  if(!is.na(x)){
    if(x>x1|x<x2){
      x='aaaaaaaaaaa'
    }else{
      x=x
    }
  }else{
    x=0
  }
  return(x)
}
