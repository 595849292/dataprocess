fun1 <-
function(x){
  r<-sum(x=='aaaaaaaaaaa',na.rm = TRUE)
  return(r)
}
