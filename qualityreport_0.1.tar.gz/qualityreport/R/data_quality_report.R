data_quality_report <-
function(data,vec){
  report_total<-sapply(data,length)
  report_na<-sapply(data,f_na_sta)
  report_space<-sapply(data,f_space_sta)
  report_empty<-sapply(data,f_empty_sta)
  report_outlier1<-sapply(data[vec],f_outlier)
  report_outlier<-rep(0,length(report_total))
  report_outlier[vec]=report_outlier1
  report<-data.frame(total=report_total,null_value=report_na,empty_value=report_empty,white_space=report_space,report_outlier=report_outlier)
  return(report)
}
