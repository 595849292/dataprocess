f_outlier <-
function(x){
  mea<-mean(x,na.rm = TRUE)
  std<-sd(x,na.rm=TRUE)
  x1<-mea+3*std
  x2<-mea-3*std
  res1<-sapply(x,f_outlier_deep,x1=x1,x2=x2)
  res1<-data.frame(res1)
  res<-sapply(res1,fun1)
  return(res)
}
