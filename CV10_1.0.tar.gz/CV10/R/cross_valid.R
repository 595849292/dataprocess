cross_valid <-
function(data,vec_y){
  data<-data[order(data[vec_y]),]
  result<-split(row.names(data),data[vec_y])
  result1<-as.numeric(unlist(result[1]))
  result2<-as.numeric(unlist(result[2]))
  result11<-cut(result1,quantile(result1,probs = seq(0,1,0.1)),include.lowest = TRUE)
  result_0<-tapply(result1,result11,f)
  result21<-cut(result2,quantile(result2,probs = seq(0,1,0.1)),include.lowest = TRUE)
  result_1<-tapply(result2,result21,f)
  result_train_test<-list()
  for(i in 1:10){
    result_train_test[[i]]<-as.numeric(c(unlist(result_0[i]),unlist(result_1[i])))
  }
  return(result_train_test)
}
