f_outlier_deep <-
function(x,x1,x2){
  if(!is.na(x)){
    if(x>x1){
      x=x1
    }else if(x<x2){
      x=x2
    }else{
      x=x
    }
  }
  return(x)
}
