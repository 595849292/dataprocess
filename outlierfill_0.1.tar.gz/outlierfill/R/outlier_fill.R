outlier_fill <-
function(data,vec){
  data[vec]=sapply(data[vec],f_outlier)
  return(data)
}
