f_dummpy <-
function(data,x){
  #x means vector ,you want the column index 
  #data is the data.frame 
  #re4 is data.frame
  library(nnet)
  new_data<-data[x]
  re1<-sapply(new_data,class.ind)
  re2<-matrix(unlist(re1),nrow=dim(data)[1])
  re3<-cbind(data,re2)
  re4<-re3[-x]
  return(re4)
}
